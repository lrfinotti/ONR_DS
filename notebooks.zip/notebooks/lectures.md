# Data Analysis with Python

# Topics

1. Introduction to Python
2. Numerical Computations with NumPy (?)
3. Data Frames with Pandas
4. Data Visualization
5. Randomization
6. Testing Hypotheses
7. A/B Testing
8. Inference
9. Predictions with Linear Regression
10. Classification with Nearest Neighbors
